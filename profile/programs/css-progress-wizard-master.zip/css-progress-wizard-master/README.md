[![MIT Badge](http://img.shields.io/badge/license-MIT-blue.svg)](https://raw.githubusercontent.com/christabor/css-progress-wizard/master/LICENSE)
![Donation badge](https://img.shields.io/gratipay/christabor.svg)

## A pure css progress indicator!
* Pure CSS (lightweight, easy to implement)
* Flexbox - easy to update and add more items
* Resizeable/responsive (text-resize, etc... try it!)
* Easy to customize design (sass mixins/variables, etc...)
* Written with SASS
